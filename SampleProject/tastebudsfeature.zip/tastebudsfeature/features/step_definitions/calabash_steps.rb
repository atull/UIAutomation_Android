
Given (/^should be on Login Page/) do
  wait_for_elements_exist("android.widget.EditText id:'edtUsername'}", :timeout => 30)
end

Given (/^login with valid user/) do
  wait_for_elements_exist("android.widget.EditText id:'edtUsername'}", :timeout => 30)
  clear_text_in("android.widget.EditText id:'edtUsername'}")
  enter_text("android.widget.EditText id:'edtUsername'}", "sameer.more@inin.com" )
  clear_text_in("android.widget.EditText id:'edtPassword'}")
  enter_text("android.widget.EditText id:'edtPassword'}", "123456789")
  tap_when_element_exists("* marked:'login'")
end

When (/^enter User Name as ([^\"]*)/) do |userId|
  clear_text_in("android.widget.EditText id:'edtUsername'}")
  enter_text("android.widget.EditText id:'edtUsername'}", userId)
end

And (/^enter Password as ([^\"]*)/) do |password|
  clear_text_in("android.widget.EditText id:'edtPassword'}")
  enter_text("android.widget.EditText id:'edtPassword'}", password)
end

And (/^click on login/) do
  sleep(1)
  tap_when_element_exists("* marked:'login'")
end

Then (/^verify Invalid Credential/) do
  puts "Invalid Credentials"
end


Then(/^Verify on home page/) do
  sleep(1)
  puts "You are on home page"
end









