When (/^click navigation drower/) do
  tap_when_element_exists("android.view.View marked:'Open'")
  sleep(1)
end

And (/^open feedbackform/) do
  touch("android.view.View marked:'Feed Back'")
  sleep(1)
end

And (/^enter name as ([^\"]*)/) do |name|
  clear_text_in("android.widget.EditText id:'editText'}")
  enter_text("android.widget.EditText id:'editText'}", name)
end

And (/^select gender as ([^\"]*)/) do |gender|
  touch("android.view.View marked:'#{gender}'")
end

And (/^checked hobbies as ([^\"]*)/) do |hobbies|
  touch("android.view.View marked:'New CheckBox'")
end

And (/^select profession as ([^\"]*)/) do |profession|
  touch("* id:'spinner'")
  sleep(1)
  touch("* {text CONTAINS '#{profession}'}")
  sleep(1)
end

And (/^click submit/) do
  touch("* id:'btnsubmit'")
  sleep(10)
end