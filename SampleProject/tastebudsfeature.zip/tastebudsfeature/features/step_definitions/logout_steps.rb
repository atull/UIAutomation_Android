
When (/^customer is on home page/) do
  puts "You are on home page"

end
And (/^customer taps on menu/) do
  performAction('press_menu')
end

And (/^customer taps on logout/) do
  touch("* {text CONTAINS 'Logout'}")
end

Then(/^navigate on login page/) do
  puts "You now on login page"
end